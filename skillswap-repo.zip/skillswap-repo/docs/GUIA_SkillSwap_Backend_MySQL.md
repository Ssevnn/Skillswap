# SkillSwap — Guía paso a paso: de HTML estático a plataforma completa con MySQL

> Guía de implementación del backend, la base de datos MySQL, la seguridad, las pruebas y el despliegue.
> Basada en la propuesta del proyecto (PDF) y en el frontend ya convertido a HTML5 (11 páginas).

---

## Índice

0. Dónde estamos y qué falta
1. Cuatro ajustes que debes hacer a la propuesta antes de programar
2. Primero lo primero: el laboratorio del lunes 12 de octubre
3. Instalar las herramientas
4. Estructura del repositorio
5. Base de datos MySQL (modelo, script SQL, datos iniciales)
6. Backend con Node.js + Express (código base)
7. Módulos del sistema: endpoints y código clave
8. Conectar el frontend con la API
9. Seguridad: checklist contra la propuesta
10. Pruebas
11. Despliegue (Aiven MySQL + Render)
12. Cronograma por sprints y reparto del equipo
13. Documentación y sustentación final

---

## 0. Dónde estamos y qué falta

El frontend ya tiene todas las pantallas, pero **los datos son de ejemplo** (escritos a mano en el HTML o guardados en `localStorage`). No existe servidor ni base de datos: cualquiera puede "entrar" sin contraseña.

| # | Módulo de la propuesta | Pantalla (frontend) | Estado del frontend | Lo que falta (backend / BD) |
|---|---|---|---|---|
| 1 | Autenticación | `login.html`, `registro.html` | Formulario listo, no valida nada | Registro, login con JWT, logout, recuperar contraseña |
| 2 | Perfil | `perfil.html` | Editable, guarda en el navegador | Guardar perfil, habilidades y disponibilidad en MySQL |
| 3 | Búsqueda y exploración | `explorar.html` | Filtros sobre 6 estudiantes fijos | Búsqueda real con filtros por categoría, carrera y texto |
| 4 | Coincidencias (Matches) | `explorar.html`, `portal.html` | Porcentajes escritos a mano | Algoritmo que calcule el % de coincidencia |
| 5 | Intercambios | `sesiones.html` | Lista fija | Solicitudes con estados Pendiente / Aceptado / Rechazado / Finalizado |
| 6 | Chat | `mensajes.html` | Mensajes solo en pantalla | Mensajería en tiempo real (Socket.io) guardada en MySQL |
| 7 | Calificaciones y reputación | *(solo una reseña en `perfil.html`)* | **No hay pantalla para calificar** | Pantalla + tabla de reseñas (puntualidad, conocimiento, responsabilidad) |
| 8 | Gamificación (SkillPoints) | `tienda.html` | Puntos en `localStorage` | Libro de puntos en MySQL, canje de recompensas |
| 9 | Panel administrativo | `admin.html` | Datos fijos | Estadísticas, moderación de reportes, gestión de usuarios y categorías |

**Piezas que el diseño aún no tiene y la propuesta sí menciona:**

- Pantalla para **calificar** una sesión finalizada (módulo 7).
- Pantalla de **recuperar contraseña** (módulo 1).
- Botones para **reportar y bloquear** usuarios (sección "Protección de sesión y datos").
- Separar **estudiante** y **administrador**: hoy el enlace "Administración" lo ve cualquiera.

---

## 1. Cuatro ajustes que debes hacer a la propuesta antes de programar

La nota del PDF dice que la propuesta debe ser **coherente** entre problemática, objetivos, módulos, tecnología, cronograma y alcance. Hoy hay cuatro puntos que no lo son:

### 1.1 Supabase es PostgreSQL, no MySQL
Tu propuesta lista "Supabase o Aiven" para alojar la base de datos. Supabase solo ofrece PostgreSQL. Como eligieron **MySQL**, el servicio de hosting debe ser **Aiven for MySQL**, que tiene un plan gratuito de una sola máquina con 1 CPU, 1 GB de RAM y 1 GB de disco, sin tarjeta de crédito.
Límites a tener en cuenta: Aiven puede apagar servicios gratuitos que lleven tiempo sin usarse (avisa antes y se pueden volver a encender).
Fuente: <https://aiven.io/docs/products/mysql/concepts/mysql-free-tier>

> **Cambio en el PDF:** fila "Hosting y despliegue" → *Render (servidor web + API + Socket.io) y Aiven for MySQL (base de datos)*.

### 1.2 Vercel no sirve para el chat en tiempo real
Vercel ejecuta el código como funciones sin estado que no mantienen conexiones WebSocket abiertas. Socket.io necesita un servidor Node que esté siempre encendido. **Usa Render para todo el servidor** (sirve el frontend, la API y el chat).
Límite del plan gratuito de Render: el servicio se duerme tras 15 minutos sin tráfico y puede reiniciarse en cualquier momento; al despertar tarda unos segundos. Socket.io reconecta solo.
Fuente: <https://render.com/docs/free>

> **Cambio en el PDF:** quitar Vercel de la lista.

### 1.3 Las membresías de pago contradicen una limitación de la propuesta
La propuesta dice en *Limitaciones*: **"No gestiona transacciones ni cobros monetarios"**. Pero `tienda.html` muestra planes de **$3.99 y $7.99 al mes**.
Elige una opción y deja el PDF y el diseño alineados:

- **A (recomendada):** eliminar la sección de membresías y dejar solo la tienda de SkillPoints.
- **B:** mantenerla como **simulación** visible ("Próximamente – demo"), sin guardar pagos ni pedir tarjetas.
- **C:** cambiar la limitación del PDF (implica integrar una pasarela de pago, fuera del alcance).

### 1.4 Falta el cronograma
La nota del PDF exige coherencia con el **cronograma**, pero el documento no tiene esa sección. La sección 12 de esta guía trae uno que puedes copiar al PDF.

---

## 2. Primero lo primero: el laboratorio del lunes 12 de octubre

El laboratorio de HTML5 se entrega el **lunes 12 de octubre de 2026** y **no requiere backend ni base de datos**. Antes de empezar lo de esta guía, cierra esto:

- [ ] Descargar la imagen del hero y el video a una carpeta `assets/` y cambiar las rutas en `index.html` (hoy dependen de Unsplash y Pexels).
- [ ] Validar cada `.html` en <https://validator.w3.org> (el laboratorio lo menciona) y corregir lo que marque.
- [ ] Tener a mano el enlace al diseño en Figma (vale 20 puntos).
- [ ] Revisar que el sitio muestre: estructura semántica, texto, imágenes, hipervínculos, video, listas enumeradas, listas no enumeradas, tabla y CSS.
- [ ] Preparar la sustentación oral (20 puntos).

Todo lo que sigue es para el proyecto completo.

---

## 3. Instalar las herramientas

### 3.1 Node.js
1. Descarga la versión marcada **LTS** desde <https://nodejs.org>.
2. Verifica en una terminal:
   ```bash
   node -v
   npm -v
   ```

### 3.2 MySQL (en tu computadora)
1. Descarga **MySQL Community Server** desde <https://dev.mysql.com/downloads/>. Elige la versión **8.4 LTS** (o la misma versión mayor que use Aiven, para evitar diferencias).
2. En Windows usa el **MySQL Installer**: instala *MySQL Server* y *MySQL Workbench*.
3. Anota la **contraseña de root** que definas y deja el puerto **3306**.
4. Verifica:
   ```bash
   mysql --version
   mysql -u root -p
   ```
   Si Windows dice que `mysql` no se reconoce, agrega la carpeta `bin` de MySQL (por ejemplo `C:\Program Files\MySQL\MySQL Server 8.4\bin`) a la variable de entorno **Path**.

> Alternativa sin instalar: Docker.
> `docker run --name skillswap-db -e MYSQL_ROOT_PASSWORD=clave -p 3306:3306 -d mysql:8.4`

### 3.3 Git y VS Code
- Git: <https://git-scm.com>. Configura tu identidad:
  ```bash
  git config --global user.name "Tu Nombre"
  git config --global user.email "tu@correo.com"
  ```
- Extensiones de VS Code recomendadas: **Database Client** (para ver las tablas dentro de VS Code), **REST Client** o la app **Postman**, **ESLint**, **Prettier**, **Markdown Preview Mermaid Support** (para ver el diagrama ER de esta guía).

---

## 4. Estructura del repositorio

Crea un repositorio en GitHub y organiza todo así. **Mueve lo que ya tienes a `frontend/`.**

```
skillswap/
├── frontend/                 ← lo que ya construimos
│   ├── index.html, login.html, registro.html, portal.html, ...
│   ├── css/styles.css
│   └── js/ (main.js, api.js, pages/...)
├── backend/
│   ├── package.json
│   ├── .env                  ← secretos locales (NO se sube a Git)
│   ├── .env.example          ← plantilla sin secretos (sí se sube)
│   ├── sql/
│   │   ├── schema.sql        ← tablas
│   │   └── seed.sql          ← datos iniciales
│   └── src/
│       ├── server.js
│       ├── db.js
│       ├── middleware/       ← auth.js, csrf.js
│       ├── routes/           ← auth.js, users.js, matches.js, exchanges.js, ...
│       ├── services/         ← matching.js, points.js
│       ├── sockets/          ← chat.js
│       └── scripts/          ← createAdmin.js
├── .gitignore
└── README.md
```

`.gitignore` mínimo:

```
node_modules/
.env
*.log
.DS_Store
```

**Decisión clave:** Express va a servir el frontend desde la misma dirección que la API. Así no hay problemas de CORS, y las cookies seguras (HttpOnly + SameSite) funcionan sin configuración extra.

> ⚠️ Mientras desarrollas, abre siempre el sitio en **`http://localhost:3000`** (el servidor Express), **no** con Live Server (puerto 5500). Si el frontend y la API están en puertos distintos, las cookies de sesión dejan de funcionar.

---

## 5. Base de datos MySQL

### 5.1 Crear la base y un usuario propio para la aplicación

La aplicación **nunca** debe conectarse con `root`. Crea un usuario con los permisos mínimos. Abre `mysql -u root -p` (o una pestaña SQL en Workbench) y ejecuta:

```sql
CREATE DATABASE skillswap CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER 'skillswap_app'@'localhost' IDENTIFIED BY 'cambia_esta_clave';
GRANT SELECT, INSERT, UPDATE, DELETE ON skillswap.* TO 'skillswap_app'@'localhost';
FLUSH PRIVILEGES;
```

> El usuario `skillswap_app` no puede crear ni borrar tablas. Las tablas las creas tú con `root` (paso 5.4).

### 5.2 Modelo entidad-relación

Reglas de negocio que el modelo respeta (sácalas tal cual para el informe):

- Un usuario tiene **un rol** (estudiante o administrador).
- Un usuario declara muchas habilidades, cada una como **"ofrece"** o **"busca"**. Una habilidad **no puede ser ambas** para el mismo usuario (lo valida la API).
- Un **intercambio** es una sesión en una dirección: *quien aprende* solicita a *quien enseña* una habilidad. El "trueque" se completa cuando ambos se enseñan mutuamente (dos intercambios, o uno con `offered_skill_id`).
- Los **SkillPoints** no se editan directamente: cada cambio es una fila en un **libro de movimientos** (`points_ledger`), y `users.skill_points` guarda el saldo.
- Una reseña pertenece a un intercambio finalizado y solo puede escribirla un participante, una vez.

```mermaid
erDiagram
  roles ||--o{ users : "tiene"
  users ||--o{ user_skills : "declara"
  skills ||--o{ user_skills : "aparece en"
  categories ||--o{ skills : "agrupa"
  users ||--o{ availability : "define"
  users ||--o{ exchanges : "aprende (learner)"
  users ||--o{ exchanges : "ensena (teacher)"
  skills ||--o{ exchanges : "trata sobre"
  exchanges ||--o{ reviews : "genera"
  users ||--o{ messages : "envia"
  users ||--o{ points_ledger : "acumula"
  rewards ||--o{ user_rewards : "se canjea"
  users ||--o{ user_rewards : "posee"
  users ||--o{ reports : "reporta"
  users ||--o{ blocks : "bloquea"
  users ||--o{ password_resets : "solicita"
```

### 5.3 Script de tablas — `backend/sql/schema.sql`

```sql
USE skillswap;

-- ---------- Usuarios y roles ----------
CREATE TABLE roles (
  id   TINYINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(20) NOT NULL UNIQUE            -- 'estudiante' | 'administrador'
);

CREATE TABLE users (
  id            INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  role_id       TINYINT UNSIGNED NOT NULL DEFAULT 1,
  full_name     VARCHAR(120) NOT NULL,
  email         VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,        -- hash bcrypt, NUNCA la contraseña
  career        VARCHAR(100),
  semester      VARCHAR(30),
  bio           TEXT,
  avatar_url    VARCHAR(255),
  banner_url    VARCHAR(255),
  decoration    VARCHAR(30) NOT NULL DEFAULT 'classic',
  status        ENUM('activo','en_revision','bloqueado') NOT NULL DEFAULT 'activo',
  skill_points  INT NOT NULL DEFAULT 0,       -- saldo; se mueve solo vía points_ledger
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_users_role FOREIGN KEY (role_id) REFERENCES roles(id),
  CONSTRAINT chk_points_nonneg CHECK (skill_points >= 0)
);

CREATE TABLE password_resets (
  id         INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  user_id    INT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL,               -- SHA-256 del token enviado por correo
  expires_at DATETIME NOT NULL,
  used_at    DATETIME NULL,
  CONSTRAINT fk_reset_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_reset_token (token_hash)
);

-- ---------- Habilidades ----------
CREATE TABLE categories (
  id   SMALLINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(60) NOT NULL UNIQUE
);

CREATE TABLE skills (
  id          INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  category_id SMALLINT UNSIGNED NOT NULL,
  name        VARCHAR(80) NOT NULL UNIQUE,
  CONSTRAINT fk_skills_cat FOREIGN KEY (category_id) REFERENCES categories(id)
);

CREATE TABLE user_skills (
  user_id  INT UNSIGNED NOT NULL,
  skill_id INT UNSIGNED NOT NULL,
  kind     ENUM('ofrece','busca') NOT NULL,
  PRIMARY KEY (user_id, skill_id, kind),
  CONSTRAINT fk_us_user  FOREIGN KEY (user_id)  REFERENCES users(id)  ON DELETE CASCADE,
  CONSTRAINT fk_us_skill FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE CASCADE,
  INDEX idx_us_skill (skill_id, kind)
);

CREATE TABLE availability (
  id         INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  user_id    INT UNSIGNED NOT NULL,
  weekday    TINYINT UNSIGNED NOT NULL,       -- 1 = lunes ... 7 = domingo
  start_time TIME NOT NULL,
  end_time   TIME NOT NULL,
  CONSTRAINT fk_av_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT chk_av_day  CHECK (weekday BETWEEN 1 AND 7),
  CONSTRAINT chk_av_time CHECK (end_time > start_time)
);

-- ---------- Intercambios ----------
CREATE TABLE exchanges (
  id               INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  learner_id       INT UNSIGNED NOT NULL,     -- quien solicita y aprende
  teacher_id       INT UNSIGNED NOT NULL,     -- quien enseña
  skill_id         INT UNSIGNED NOT NULL,     -- habilidad que se enseña
  offered_skill_id INT UNSIGNED NULL,         -- lo que el aprendiz ofrece a cambio (trueque)
  status           ENUM('pendiente','aceptado','rechazado','finalizado') NOT NULL DEFAULT 'pendiente',
  scheduled_at     DATETIME NULL,             -- se guarda en UTC
  duration_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 60,
  modality         ENUM('virtual','presencial') NULL,
  meeting_url      VARCHAR(255) NULL,         -- enlace de Meet / Teams (limitación de la propuesta)
  location         VARCHAR(150) NULL,
  created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_ex_learner FOREIGN KEY (learner_id) REFERENCES users(id),
  CONSTRAINT fk_ex_teacher FOREIGN KEY (teacher_id) REFERENCES users(id),
  CONSTRAINT fk_ex_skill   FOREIGN KEY (skill_id)   REFERENCES skills(id),
  CONSTRAINT fk_ex_offered FOREIGN KEY (offered_skill_id) REFERENCES skills(id),
  CONSTRAINT chk_ex_diff   CHECK (learner_id <> teacher_id),
  INDEX idx_ex_teacher (teacher_id, status),
  INDEX idx_ex_learner (learner_id, status)
);

-- ---------- Chat ----------
CREATE TABLE messages (
  id          BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  sender_id   INT UNSIGNED NOT NULL,
  receiver_id INT UNSIGNED NOT NULL,
  body        VARCHAR(1000) NOT NULL,
  sent_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  read_at     TIMESTAMP NULL,
  CONSTRAINT fk_msg_sender   FOREIGN KEY (sender_id)   REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_msg_receiver FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_msg_pair (sender_id, receiver_id, sent_at),
  INDEX idx_msg_inbox (receiver_id, read_at)
);

-- ---------- Calificaciones ----------
CREATE TABLE reviews (
  id             INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  exchange_id    INT UNSIGNED NOT NULL,
  reviewer_id    INT UNSIGNED NOT NULL,
  reviewed_id    INT UNSIGNED NOT NULL,
  punctuality    TINYINT UNSIGNED NOT NULL,
  knowledge      TINYINT UNSIGNED NOT NULL,
  responsibility TINYINT UNSIGNED NOT NULL,
  comment        VARCHAR(500) NULL,
  created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_review_once (exchange_id, reviewer_id),
  CONSTRAINT fk_rev_ex       FOREIGN KEY (exchange_id) REFERENCES exchanges(id) ON DELETE CASCADE,
  CONSTRAINT fk_rev_reviewer FOREIGN KEY (reviewer_id) REFERENCES users(id),
  CONSTRAINT fk_rev_reviewed FOREIGN KEY (reviewed_id) REFERENCES users(id),
  CONSTRAINT chk_rev_p CHECK (punctuality    BETWEEN 1 AND 5),
  CONSTRAINT chk_rev_k CHECK (knowledge      BETWEEN 1 AND 5),
  CONSTRAINT chk_rev_r CHECK (responsibility BETWEEN 1 AND 5)
);

-- ---------- SkillPoints y tienda ----------
CREATE TABLE rewards (
  id          INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  type        ENUM('beneficio','decoracion') NOT NULL,
  code        VARCHAR(30) NOT NULL UNIQUE,    -- p. ej. 'aura', 'perfil_destacado'
  title       VARCHAR(80) NOT NULL,
  description VARCHAR(200) NOT NULL,
  cost        INT UNSIGNED NOT NULL,
  active      BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE user_rewards (
  user_id    INT UNSIGNED NOT NULL,
  reward_id  INT UNSIGNED NOT NULL,
  claimed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, reward_id),
  CONSTRAINT fk_ur_user   FOREIGN KEY (user_id)   REFERENCES users(id)   ON DELETE CASCADE,
  CONSTRAINT fk_ur_reward FOREIGN KEY (reward_id) REFERENCES rewards(id)
);

CREATE TABLE points_ledger (
  id          BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  user_id     INT UNSIGNED NOT NULL,
  amount      INT NOT NULL,                   -- positivo = gana, negativo = gasta
  reason      ENUM('hora_ensenada','sesion_completada','bono_resena','canje') NOT NULL,
  exchange_id INT UNSIGNED NULL,
  reward_id   INT UNSIGNED NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pl_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_pl_user (user_id, created_at)
);

-- ---------- Moderación ----------
CREATE TABLE reports (
  id          INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  reporter_id INT UNSIGNED NOT NULL,
  reported_id INT UNSIGNED NOT NULL,
  reason      VARCHAR(120) NOT NULL,
  details     TEXT NULL,
  status      ENUM('pendiente','resuelto') NOT NULL DEFAULT 'pendiente',
  resolved_by INT UNSIGNED NULL,
  resolved_at DATETIME NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_rep_reporter FOREIGN KEY (reporter_id) REFERENCES users(id),
  CONSTRAINT fk_rep_reported FOREIGN KEY (reported_id) REFERENCES users(id),
  INDEX idx_rep_status (status, created_at)
);

CREATE TABLE blocks (
  blocker_id INT UNSIGNED NOT NULL,
  blocked_id INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (blocker_id, blocked_id),
  CONSTRAINT fk_bl_blocker FOREIGN KEY (blocker_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_bl_blocked FOREIGN KEY (blocked_id) REFERENCES users(id) ON DELETE CASCADE
);
```

### 5.4 Datos iniciales — `backend/sql/seed.sql`

```sql
USE skillswap;

INSERT INTO roles (id, name) VALUES (1, 'estudiante'), (2, 'administrador');

INSERT INTO categories (name) VALUES ('Tecnología'), ('Idiomas'), ('Diseño'), ('Ciencias');

INSERT INTO skills (category_id, name) VALUES
  (1, 'Python'), (1, 'Java'), (1, 'Git'), (1, 'SQL'), (1, 'Ciberseguridad'), (1, 'Redes'), (1, 'Excel'),
  (2, 'Inglés'), (2, 'Francés'), (2, 'Portugués'),
  (3, 'Figma'), (3, 'UX/UI'),
  (4, 'Cálculo'), (4, 'Física'), (4, 'Estadística');

INSERT INTO rewards (type, code, title, description, cost) VALUES
  ('beneficio','perfil_destacado','Perfil destacado','Aparece primero en los resultados durante 7 días.',450),
  ('beneficio','insignia_mentor','Insignia Mentor','Muestra tu experiencia y compromiso en el perfil.',700),
  ('beneficio','cambio_match','Cambio de match','Desbloquea tres recomendaciones adicionales.',250),
  ('beneficio','tema_nocturno','Tema nocturno','Personaliza tu experiencia con un tema exclusivo.',350),
  ('beneficio','taller_premium','Taller premium','Accede a un taller grupal impartido por un mentor.',900),
  ('beneficio','racha_protegida','Racha protegida','Conserva tu racha si omites una semana.',200),
  ('decoracion','aura','Aura eléctrica','Un aro azul brillante para destacar tu avatar.',320),
  ('decoracion','neon','Neón coral','Borde luminoso con los colores de SkillSwap.',450),
  ('decoracion','laurels','Laureles de mentor','Reconoce visualmente tu experiencia enseñando.',600),
  ('decoracion','cosmos','Órbita cósmica','Una órbita animada exclusiva para tu perfil.',750);
```

### 5.5 Cargar los scripts

Desde la carpeta `backend/`, con **root** (no con `skillswap_app`):

```bash
mysql -u root -p < sql/schema.sql
mysql -u root -p < sql/seed.sql
```

O en Workbench: *File → Open SQL Script → ejecutar (⚡)*. Comprueba:

```sql
USE skillswap;
SHOW TABLES;                       -- deben aparecer 15 tablas
SELECT * FROM categories;
```

> El script `schema.sql` empieza con `USE skillswap;`. En Aiven la base se llama normalmente `defaultdb` (ver sección 11): cambia esa línea o crea la base con `CREATE DATABASE skillswap;`.

### 5.6 Buenas prácticas que aplican a toda la base

- **Consultas parametrizadas siempre** (`:nombre` o `?`), jamás concatenar texto del usuario dentro del SQL. Es la defensa contra inyección SQL que pide la propuesta.
- **Fechas en UTC**: la base guarda UTC y el navegador las muestra en la hora local (Panamá, UTC−5).
- **Contraseñas**: solo el hash bcrypt en `password_hash`.
- **Copias de seguridad** antes de la sustentación: `mysqldump -u root -p skillswap > respaldo.sql`.

---

## 6. Backend con Node.js + Express (código base)

### 6.1 Crear el proyecto

```bash
cd backend
npm init -y
npm install express mysql2 bcrypt jsonwebtoken cookie cookie-parser helmet express-rate-limit zod dotenv socket.io
npm install -D nodemon
```

Abre `backend/package.json` y deja estas líneas (el `"type": "module"` permite usar `import`):

```json
{
  "name": "skillswap-backend",
  "version": "1.0.0",
  "type": "module",
  "engines": { "node": ">=20" },
  "scripts": {
    "dev": "nodemon src/server.js",
    "start": "node src/server.js"
  }
}
```

> Si `bcrypt` falla al instalarse en tu computadora, usa `bcryptjs` (misma API, solo cambia el `import`). La propuesta pide el algoritmo bcrypt, y ambos paquetes lo implementan.

### 6.2 Variables de entorno

`backend/.env.example` (se sube a Git) — cada integrante lo copia a `.env` y pone sus valores:

```
NODE_ENV=development
PORT=3000

DB_HOST=localhost
DB_PORT=3306
DB_USER=skillswap_app
DB_PASSWORD=
DB_NAME=skillswap
DB_SSL=false
DB_CA=

JWT_SECRET=
ALLOWED_EMAIL_DOMAIN=utp.ac.pa
```

Genera un `JWT_SECRET` largo y aleatorio:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

### 6.3 Conexión a MySQL — `src/db.js`

```js
import mysql from 'mysql2/promise';

export const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  namedPlaceholders: true,   // permite :nombre en vez de ?
  timezone: 'Z',             // todo en UTC
  // Aiven exige conexión cifrada (SSL) con su certificado
  ssl: process.env.DB_SSL === 'true'
    ? { rejectUnauthorized: true, ca: process.env.DB_CA?.replace(/\\n/g, '\n') }
    : undefined,
});
```

### 6.4 Servidor principal — `src/server.js`

```js
import 'dotenv/config';
import path from 'node:path';
import http from 'node:http';
import { fileURLToPath } from 'node:url';
import express from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import { Server } from 'socket.io';

import { pool } from './db.js';
import { csrfProtection } from './middleware/csrf.js';
import { setupChat } from './sockets/chat.js';
import authRoutes from './routes/auth.js';
import userRoutes from './routes/users.js';
import matchRoutes from './routes/matches.js';
import exchangeRoutes from './routes/exchanges.js';
// ...importa aquí el resto de rutas (messages, reviews, store, reports, admin)

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const FRONTEND = path.join(__dirname, '../../frontend');
const isProd = process.env.NODE_ENV === 'production';

const app = express();
app.set('trust proxy', 1);                       // Render va detrás de un proxy HTTPS

// Cabeceras de seguridad + política de contenido (ayuda contra XSS)
app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      'style-src': ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      'font-src': ["'self'", 'https://fonts.gstatic.com'],
      'img-src': ["'self'", 'data:', 'https://images.unsplash.com'],
      'media-src': ["'self'", 'https://videos.pexels.com'],
      'upgrade-insecure-requests': isProd ? [] : null,   // en local (http) se desactiva
    },
  },
}));

app.use(express.json({ limit: '100kb' }));
app.use(cookieParser());

// Límite general y uno más estricto para el login (contra fuerza bruta)
app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use('/api/auth/login', rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: 'draft-7', legacyHeaders: false }));

app.get('/api/health', async (req, res) => {
  try { await pool.query('SELECT 1'); res.json({ ok: true }); }
  catch { res.status(500).json({ ok: false }); }
});

app.use('/api/auth', authRoutes);                // login/registro: antes del CSRF
app.use('/api', csrfProtection);                 // todo lo demás exige token CSRF
app.use('/api/users', userRoutes);
app.use('/api/matches', matchRoutes);
app.use('/api/exchanges', exchangeRoutes);
// app.use('/api/messages', ...); app.use('/api/store', ...); app.use('/api/admin', ...); ...

app.use('/api', (req, res) => res.status(404).json({ error: 'Ruta no encontrada' }));

// Frontend estático
app.use(express.static(FRONTEND));
app.use((req, res) => res.status(404).sendFile(path.join(FRONTEND, '404.html')));

// Manejador global de errores (no filtra detalles internos al cliente)
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Error interno del servidor' });
});

const server = http.createServer(app);
const io = new Server(server);                   // mismo origen: no necesita CORS
setupChat(io);

const port = Number(process.env.PORT || 3000);
server.listen(port, () => console.log(`SkillSwap en http://localhost:${port}`));
```

Ejecuta `npm run dev` y abre <http://localhost:3000/api/health>: debe responder `{"ok":true}`. Si responde `false`, revisa tu `.env`.

### 6.5 Middleware de autenticación y roles — `src/middleware/auth.js`

```js
import jwt from 'jsonwebtoken';

export function requireAuth(req, res, next) {
  const token = req.cookies?.token;
  if (!token) return res.status(401).json({ error: 'No autenticado' });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);   // { uid, role }
    next();
  } catch {
    res.status(401).json({ error: 'Sesión inválida o expirada' });
  }
}

// RBAC: requireRole('administrador')
export const requireRole = (...roles) => (req, res, next) =>
  roles.includes(req.user?.role)
    ? next()
    : res.status(403).json({ error: 'No tienes permiso para esta acción' });
```

### 6.6 Protección CSRF — `src/middleware/csrf.js`

Funciona con el patrón *double-submit cookie*: al iniciar sesión el servidor entrega una cookie `csrf_token` legible por JavaScript; el frontend la copia en la cabecera `X-CSRF-Token` en cada petición que modifica datos; el servidor compara ambas. Junto con `SameSite=Strict`, un sitio externo no puede falsificar la petición.

```js
import crypto from 'node:crypto';

export function csrfProtection(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const cookie = req.cookies?.csrf_token;
  const header = req.get('x-csrf-token');
  const ok = cookie && header && cookie.length === header.length &&
    crypto.timingSafeEqual(Buffer.from(cookie), Buffer.from(header));
  if (!ok) return res.status(403).json({ error: 'Token CSRF inválido' });
  next();
}
```

### 6.7 Autenticación — `src/routes/auth.js`

```js
import { Router } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import { z } from 'zod';
import { pool } from '../db.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();

const registerSchema = z.object({
  fullName: z.string().trim().min(3).max(120),
  email: z.string().trim().toLowerCase().email().max(150)
    .refine((e) => e.endsWith('@' + process.env.ALLOWED_EMAIL_DOMAIN), 'Usa tu correo universitario'),
  password: z.string().min(8).max(72),          // bcrypt solo usa los primeros 72 bytes
  career: z.string().trim().max(100),
  semester: z.string().trim().max(30),
});

const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email(),
  password: z.string().min(1).max(72),
});

function issueSession(res, user) {
  const token = jwt.sign({ uid: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '2h' });
  const csrf = crypto.randomBytes(24).toString('hex');
  const base = {
    sameSite: 'strict',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 2 * 60 * 60 * 1000,
  };
  res.cookie('token', token, { ...base, httpOnly: true });      // JavaScript NO puede leerla (anti-XSS)
  res.cookie('csrf_token', csrf, { ...base, httpOnly: false });  // el frontend la copia a una cabecera
}

router.post('/register', async (req, res, next) => {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Datos inválidos', details: parsed.error.flatten().fieldErrors });
  }
  const { fullName, email, password, career, semester } = parsed.data;
  try {
    const hash = await bcrypt.hash(password, 12);
    const [r] = await pool.execute(
      `INSERT INTO users (full_name, email, password_hash, career, semester)
       VALUES (:fullName, :email, :hash, :career, :semester)`,
      { fullName, email, hash, career, semester },
    );
    issueSession(res, { id: r.insertId, role: 'estudiante' });
    res.status(201).json({ id: r.insertId, fullName, email, role: 'estudiante' });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Ese correo ya está registrado' });
    next(e);
  }
});

router.post('/login', async (req, res, next) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Datos inválidos' });
  const { email, password } = parsed.data;
  try {
    const [[user]] = await pool.execute(
      `SELECT u.id, u.full_name, u.password_hash, u.status, r.name AS role
         FROM users u JOIN roles r ON r.id = u.role_id
        WHERE u.email = :email`,
      { email },
    );
    // Mismo mensaje si el correo no existe o la clave es incorrecta (no revela cuentas)
    const valid = user && await bcrypt.compare(password, user.password_hash);
    if (!valid) return res.status(401).json({ error: 'Correo o contraseña incorrectos' });
    if (user.status === 'bloqueado') return res.status(403).json({ error: 'Cuenta bloqueada' });

    issueSession(res, user);
    res.json({ id: user.id, fullName: user.full_name, role: user.role });
  } catch (e) { next(e); }
});

router.post('/logout', (req, res) => {
  res.clearCookie('token');
  res.clearCookie('csrf_token');
  res.json({ ok: true });
});

router.get('/me', requireAuth, async (req, res, next) => {
  try {
    const [[me]] = await pool.execute(
      `SELECT u.id, u.full_name AS fullName, u.email, u.career, u.semester, u.decoration,
              u.avatar_url AS avatarUrl, u.skill_points AS skillPoints, r.name AS role
         FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = :uid`,
      { uid: req.user.uid },
    );
    if (!me) return res.status(401).json({ error: 'Usuario no encontrado' });
    res.json(me);
  } catch (e) { next(e); }
});

export default router;
```

**Crear el primer administrador** (nadie puede registrarse como admin desde el formulario). `src/scripts/createAdmin.js`:

```js
import 'dotenv/config';
import bcrypt from 'bcrypt';
import { pool } from '../db.js';

const [email, password] = process.argv.slice(2);
if (!email || !password) {
  console.error('Uso: node src/scripts/createAdmin.js correo clave');
  process.exit(1);
}
const hash = await bcrypt.hash(password, 12);
await pool.execute(
  "INSERT INTO users (role_id, full_name, email, password_hash) VALUES (2, 'Administrador', :email, :hash)",
  { email, hash },
);
console.log('Administrador creado');
await pool.end();
```

```bash
node src/scripts/createAdmin.js admin@utp.ac.pa UnaClaveLarga123
```

> Para la **recuperación de contraseña** necesitas enviar correos. Para el proyecto basta con generar el token, guardarlo hasheado en `password_resets` y mostrar el enlace en la consola del servidor (`console.log`) durante la demostración; el envío real se puede hacer con un servicio SMTP gratuito (por ejemplo, Brevo o Gmail con contraseña de aplicación) como mejora opcional.

---

## 7. Módulos del sistema: endpoints y código clave

### 7.1 Mapa completo de la API

Todas las rutas empiezan con `/api`. "🔒" = exige sesión iniciada; "👑" = solo administrador. Las que modifican datos (POST/PUT/PATCH/DELETE) además exigen la cabecera `X-CSRF-Token`.

| Módulo | Método y ruta | Qué hace | Pantalla |
|---|---|---|---|
| 1 Auth | `POST /auth/register` | Crea cuenta de estudiante | `registro.html` |
| | `POST /auth/login` · `POST /auth/logout` | Inicia / cierra sesión | `login.html` |
| | `GET /auth/me` 🔒 | Datos del usuario en sesión | todas |
| | `POST /auth/forgot` · `POST /auth/reset` | Recuperar contraseña | *(nueva pantalla)* |
| 2 Perfil | `GET /users/me` · `PUT /users/me` 🔒 | Ver / editar perfil | `perfil.html` |
| | `PUT /users/me/skills` 🔒 | Guardar habilidades que ofrece y busca | `perfil.html` |
| | `PUT /users/me/availability` 🔒 | Guardar horarios | `perfil.html` |
| | `PUT /users/me/decoration` 🔒 | Equipar decoración (solo las que posee) | `perfil.html` |
| | `GET /users/:id` 🔒 | Perfil público de otro estudiante | `explorar.html` |
| 3 Búsqueda | `GET /users?category=&career=&q=` 🔒 | Buscar estudiantes con filtros | `explorar.html` |
| | `GET /skills` · `GET /categories` | Catálogos para los filtros | varias |
| 4 Matches | `GET /matches` 🔒 | Estudiantes compatibles con su %, de mayor a menor | `explorar.html`, `portal.html` |
| 5 Intercambios | `POST /exchanges` 🔒 | Solicitar intercambio (queda *pendiente*) | `explorar.html` |
| | `GET /exchanges?status=` 🔒 | Mis sesiones (próximas, solicitudes, completadas) | `sesiones.html` |
| | `PATCH /exchanges/:id/respond` 🔒 | El docente acepta (con fecha y modalidad) o rechaza | `sesiones.html` |
| | `PATCH /exchanges/:id/finish` 🔒 | Marca finalizado y acredita SkillPoints | `sesiones.html` |
| 6 Chat | `GET /messages/conversations` 🔒 | Lista de conversaciones | `mensajes.html` |
| | `GET /messages/:userId` 🔒 | Historial con un usuario | `mensajes.html` |
| | Socket.io `message:send` / `message:new` | Envío y recepción en tiempo real | `mensajes.html` |
| 7 Reseñas | `POST /exchanges/:id/review` 🔒 | Calificar tras la sesión | *(nueva pantalla)* |
| | `GET /users/:id/reviews` 🔒 | Reseñas y promedios | `perfil.html` |
| 8 SkillPoints | `GET /store` 🔒 | Recompensas, decoraciones y saldo | `tienda.html` |
| | `POST /store/rewards/:id/claim` 🔒 | Canjear (descuenta puntos) | `tienda.html` |
| | `GET /points/history` 🔒 | Historial de movimientos | `tienda.html` |
| Moderación | `POST /reports` · `POST /blocks` 🔒 | Reportar / bloquear usuario | *(botones nuevos)* |
| 9 Admin | `GET /admin/stats` 👑 | Métricas generales | `admin.html` |
| | `GET /admin/users` · `PATCH /admin/users/:id/status` 👑 | Gestionar cuentas | `admin.html` |
| | `GET /admin/reports` · `PATCH /admin/reports/:id` 👑 | Moderar reportes | `admin.html` |
| | `POST /admin/categories` · `PATCH`/`DELETE` 👑 | Gestionar categorías | `admin.html` |

También necesitas `GET /dashboard` 🔒 para las tarjetas de resumen de `portal.html` (matches activos, sesiones completadas, SkillPoints, reputación).

### 7.2 Módulo 2: guardar habilidades (con la regla "no ambas")

```js
// routes/users.js (fragmento)
const skillsSchema = z.object({
  offers: z.array(z.number().int().positive()).max(30),
  seeks:  z.array(z.number().int().positive()).max(30),
}).refine((d) => !d.offers.some((id) => d.seeks.includes(id)),
          'Una habilidad no puede estar en "enseño" y en "quiero aprender"');

router.put('/me/skills', requireAuth, async (req, res, next) => {
  const p = skillsSchema.safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: 'Datos inválidos' });
  const { offers, seeks } = p.data;
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    await conn.execute('DELETE FROM user_skills WHERE user_id = :uid', { uid: req.user.uid });
    for (const skillId of offers) {
      await conn.execute("INSERT INTO user_skills (user_id, skill_id, kind) VALUES (:uid, :skillId, 'ofrece')",
        { uid: req.user.uid, skillId });
    }
    for (const skillId of seeks) {
      await conn.execute("INSERT INTO user_skills (user_id, skill_id, kind) VALUES (:uid, :skillId, 'busca')",
        { uid: req.user.uid, skillId });
    }
    await conn.commit();
    res.json({ ok: true });
  } catch (e) { await conn.rollback(); next(e); }
  finally { conn.release(); }
});
```

> Patrón de **transacción** (`beginTransaction` → `commit` / `rollback` → `release`): úsalo siempre que una operación toque varias filas o tablas. Si algo falla a la mitad, no queda nada a medias.

### 7.3 Módulo 4: algoritmo de coincidencia (Matches)

**Definición del porcentaje** (anótala en el informe):

- *Lo que yo aprendo:* de las habilidades que **yo busco**, cuántas **ofrece el otro** → `iLearn / misBusquedas`.
- *Lo que yo enseño:* de las habilidades que **el otro busca**, cuántas **ofrezco yo** → `iTeach / susBusquedas`.
- Solo hay match si **ambas partes son mayores que 0** (reciprocidad).
- **Porcentaje = promedio de ambas razones × 100.**

Ejemplo: yo busco Inglés y Figma; el otro ofrece Inglés (1 de 2 = 50 %). El otro busca Python y yo ofrezco Python (1 de 1 = 100 %). Coincidencia = (50 % + 100 %) / 2 = **75 %**.

```js
// src/services/matching.js
import { pool } from '../db.js';

export async function findMatches(userId, limit = 20) {
  const [[{ mySeeks }]] = await pool.query(
    "SELECT COUNT(*) AS mySeeks FROM user_skills WHERE user_id = :userId AND kind = 'busca'",
    { userId },
  );
  if (!mySeeks) return [];

  const [rows] = await pool.query(
    `SELECT u.id, u.full_name AS fullName, u.career, u.semester,
            SUM(theirs.kind = 'ofrece' AND mine.kind = 'busca') AS iLearn,
            SUM(theirs.kind = 'busca'  AND mine.kind = 'ofrece') AS iTeach,
            (SELECT COUNT(*) FROM user_skills x
              WHERE x.user_id = u.id AND x.kind = 'busca') AS theirSeeks
       FROM users u
       JOIN user_skills theirs ON theirs.user_id = u.id
       JOIN user_skills mine   ON mine.user_id = :userId AND mine.skill_id = theirs.skill_id
      WHERE u.id <> :userId
        AND u.status = 'activo' AND u.role_id = 1
        AND NOT EXISTS (SELECT 1 FROM blocks b
              WHERE (b.blocker_id = :userId AND b.blocked_id = u.id)
                 OR (b.blocker_id = u.id AND b.blocked_id = :userId))
      GROUP BY u.id
     HAVING iLearn > 0 AND iTeach > 0`,
    { userId },
  );

  return rows
    .map((r) => {
      const iLearn = Number(r.iLearn), iTeach = Number(r.iTeach), theirSeeks = Number(r.theirSeeks);
      return {
        id: r.id, fullName: r.fullName, career: r.career, semester: r.semester,
        matchPct: Math.round(100 * (iLearn / mySeeks + iTeach / theirSeeks) / 2),
      };
    })
    .sort((a, b) => b.matchPct - a.matchPct)
    .slice(0, limit);
}
```

```js
// src/routes/matches.js
import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { findMatches } from '../services/matching.js';

const router = Router();
router.get('/', requireAuth, async (req, res, next) => {
  try { res.json(await findMatches(req.user.uid)); } catch (e) { next(e); }
});
export default router;
```

> Los resultados de `SUM(...)` llegan como texto desde MySQL (son `DECIMAL`); por eso se convierten con `Number()`.

### 7.4 Módulo 5: ciclo de vida de un intercambio

```
 pendiente ──(docente acepta + fecha/modalidad)──▶ aceptado ──(sesión realizada)──▶ finalizado
     │
     └──(docente rechaza)──▶ rechazado
```

Reglas: solo el **docente** acepta o rechaza; solo se finaliza un intercambio **aceptado** y cuya fecha ya pasó; cada estado se cambia una sola vez.

```js
// src/routes/exchanges.js
import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../db.js';
import { requireAuth } from '../middleware/auth.js';
import { addPoints } from '../services/points.js';

const router = Router();
router.use(requireAuth);

const createSchema = z.object({
  teacherId: z.number().int().positive(),
  skillId: z.number().int().positive(),
  offeredSkillId: z.number().int().positive().optional(),
});

// Solicitar un intercambio
router.post('/', async (req, res, next) => {
  const p = createSchema.safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: 'Datos inválidos' });
  const { teacherId, skillId, offeredSkillId = null } = p.data;
  const me = req.user.uid;
  if (teacherId === me) return res.status(400).json({ error: 'No puedes solicitarte a ti mismo' });
  try {
    // El docente debe ofrecer esa habilidad, estar activo y no haber bloqueo entre ambos
    const [rows] = await pool.execute(
      `SELECT 1 FROM user_skills us JOIN users u ON u.id = us.user_id
        WHERE us.user_id = :teacherId AND us.skill_id = :skillId AND us.kind = 'ofrece'
          AND u.status = 'activo'
          AND NOT EXISTS (SELECT 1 FROM blocks b
                WHERE (b.blocker_id = :me AND b.blocked_id = :teacherId)
                   OR (b.blocker_id = :teacherId AND b.blocked_id = :me))`,
      { teacherId, skillId, me },
    );
    if (!rows.length) return res.status(400).json({ error: 'Ese estudiante no ofrece esa habilidad' });
    const [r] = await pool.execute(
      `INSERT INTO exchanges (learner_id, teacher_id, skill_id, offered_skill_id)
       VALUES (:me, :teacherId, :skillId, :offeredSkillId)`,
      { me, teacherId, skillId, offeredSkillId },
    );
    res.status(201).json({ id: r.insertId, status: 'pendiente' });
  } catch (e) { next(e); }
});

// Aceptar (con fecha y modalidad) o rechazar
const respondSchema = z.discriminatedUnion('action', [
  z.object({ action: z.literal('rechazar') }),
  z.object({
    action: z.literal('aceptar'),
    scheduledAt: z.string().datetime(),                 // ISO en UTC: 2026-10-20T21:30:00Z
    durationMinutes: z.number().int().min(15).max(240).default(60),
    modality: z.enum(['virtual', 'presencial']),
    meetingUrl: z.string().url().max(255).optional(),
    location: z.string().max(150).optional(),
  }),
]);

router.patch('/:id/respond', async (req, res, next) => {
  const p = respondSchema.safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: 'Datos inválidos' });
  const d = p.data;
  try {
    const [r] = d.action === 'rechazar'
      ? await pool.execute(
          "UPDATE exchanges SET status = 'rechazado' WHERE id = :id AND teacher_id = :me AND status = 'pendiente'",
          { id: Number(req.params.id), me: req.user.uid })
      : await pool.execute(
          `UPDATE exchanges SET status = 'aceptado', scheduled_at = :at, duration_minutes = :dur,
                  modality = :mod, meeting_url = :url, location = :loc
            WHERE id = :id AND teacher_id = :me AND status = 'pendiente'`,
          { id: Number(req.params.id), me: req.user.uid, at: new Date(d.scheduledAt),
            dur: d.durationMinutes, mod: d.modality, url: d.meetingUrl ?? null, loc: d.location ?? null });
    if (r.affectedRows === 0) return res.status(409).json({ error: 'No se puede responder esta solicitud' });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

// Finalizar + acreditar SkillPoints (todo o nada)
router.patch('/:id/finish', async (req, res, next) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [[ex]] = await conn.execute(
      'SELECT * FROM exchanges WHERE id = :id FOR UPDATE',            // bloquea la fila: evita pagar dos veces
      { id: Number(req.params.id) },
    );
    if (!ex) { await conn.rollback(); return res.status(404).json({ error: 'No existe' }); }
    if (![ex.teacher_id, ex.learner_id].includes(req.user.uid)) {
      await conn.rollback(); return res.status(403).json({ error: 'No participas en este intercambio' });
    }
    if (ex.status !== 'aceptado' || new Date(ex.scheduled_at) > new Date()) {
      await conn.rollback(); return res.status(409).json({ error: 'Aún no se puede finalizar' });
    }

    await conn.execute("UPDATE exchanges SET status = 'finalizado' WHERE id = :id", { id: ex.id });

    // Regla de la tienda: 100 puntos por hora enseñada + 50 por completar una sesión (a cada uno)
    const hoursPoints = Math.round(100 * ex.duration_minutes / 60);
    await addPoints(conn, ex.teacher_id, hoursPoints, 'hora_ensenada', { exchangeId: ex.id });
    await addPoints(conn, ex.teacher_id, 50, 'sesion_completada', { exchangeId: ex.id });
    await addPoints(conn, ex.learner_id, 50, 'sesion_completada', { exchangeId: ex.id });

    await conn.commit();
    res.json({ ok: true });
  } catch (e) { await conn.rollback(); next(e); }
  finally { conn.release(); }
});

export default router;
```

```js
// src/services/points.js — ÚNICA vía para mover puntos
export async function addPoints(conn, userId, amount, reason, { exchangeId = null, rewardId = null } = {}) {
  await conn.execute(
    `INSERT INTO points_ledger (user_id, amount, reason, exchange_id, reward_id)
     VALUES (:userId, :amount, :reason, :exchangeId, :rewardId)`,
    { userId, amount, reason, exchangeId, rewardId },
  );
  await conn.execute(
    'UPDATE users SET skill_points = skill_points + :amount WHERE id = :userId',
    { userId, amount },
  );
}
```

### 7.5 Módulo 8: canjear una recompensa

```js
// routes/store.js (fragmento)
router.post('/rewards/:id/claim', requireAuth, async (req, res, next) => {
  const uid = req.user.uid;
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [[reward]] = await conn.execute(
      'SELECT id, cost FROM rewards WHERE id = :id AND active = TRUE', { id: Number(req.params.id) });
    if (!reward) { await conn.rollback(); return res.status(404).json({ error: 'Recompensa no encontrada' }); }

    const [[me]] = await conn.execute('SELECT skill_points FROM users WHERE id = :uid FOR UPDATE', { uid });
    const [owned] = await conn.execute(
      'SELECT 1 FROM user_rewards WHERE user_id = :uid AND reward_id = :rid', { uid, rid: reward.id });
    if (owned.length) { await conn.rollback(); return res.status(409).json({ error: 'Ya la tienes' }); }
    if (me.skill_points < reward.cost) { await conn.rollback(); return res.status(409).json({ error: 'Puntos insuficientes' }); }

    await conn.execute('INSERT INTO user_rewards (user_id, reward_id) VALUES (:uid, :rid)', { uid, rid: reward.id });
    await addPoints(conn, uid, -reward.cost, 'canje', { rewardId: reward.id });
    await conn.commit();
    res.json({ ok: true, skillPoints: me.skill_points - reward.cost });
  } catch (e) { await conn.rollback(); next(e); }
  finally { conn.release(); }
});
```

> **El servidor decide, no el navegador.** El frontend nunca envía "el saldo" ni "el precio": solo pide canjear la recompensa N, y el servidor consulta el costo y el saldo en MySQL. Si lo hicieran al revés, cualquiera podría regalarse puntos desde la consola del navegador.

### 7.6 Módulo 6: chat en tiempo real — `src/sockets/chat.js`

```js
import jwt from 'jsonwebtoken';
import { parse } from 'cookie';
import { pool } from '../db.js';

export function setupChat(io) {
  // Autenticación del socket con la misma cookie de sesión
  io.use((socket, next) => {
    try {
      const { token } = parse(socket.request.headers.cookie ?? '');
      socket.user = jwt.verify(token, process.env.JWT_SECRET);
      next();
    } catch {
      next(new Error('No autorizado'));
    }
  });

  io.on('connection', (socket) => {
    const me = socket.user.uid;
    socket.join(`user:${me}`);                     // sala personal: recibe sus mensajes en todas sus pestañas

    socket.on('message:send', async ({ to, body } = {}, ack) => {
      body = String(body ?? '').trim();
      if (!Number.isInteger(to) || !body || body.length > 1000) return ack?.({ ok: false });
      try {
        // No permitir mensajes si hay un bloqueo entre ambos
        const [blocked] = await pool.execute(
          `SELECT 1 FROM blocks WHERE (blocker_id = :me AND blocked_id = :to)
                                   OR (blocker_id = :to AND blocked_id = :me)`, { me, to });
        if (blocked.length) return ack?.({ ok: false, error: 'bloqueado' });

        const [r] = await pool.execute(
          'INSERT INTO messages (sender_id, receiver_id, body) VALUES (:me, :to, :body)', { me, to, body });
        io.to(`user:${to}`).to(`user:${me}`).emit('message:new',
          { id: r.insertId, from: me, to, body, sentAt: new Date().toISOString() });
        ack?.({ ok: true });
      } catch {
        ack?.({ ok: false });
      }
    });
  });
}
```

En `mensajes.html` agrega **antes** de `main.js` (Socket.io entrega este archivo solo):

```html
<script src="/socket.io/socket.io.js"></script>
```

Y en el JavaScript de la página:

```js
const socket = io();                                // usa la cookie de sesión automáticamente
socket.on('message:new', (m) => { /* dibuja el mensaje con textContent */ });
socket.emit('message:send', { to: otroUsuarioId, body: texto }, (res) => { if (!res.ok) { /* avisa */ } });
```

Historial (para cuando abres una conversación):

```js
// routes/messages.js (fragmento)
router.get('/:userId', requireAuth, async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      `SELECT id, sender_id AS \`from\`, receiver_id AS \`to\`, body, sent_at AS sentAt
         FROM messages
        WHERE (sender_id = :me AND receiver_id = :other) OR (sender_id = :other AND receiver_id = :me)
        ORDER BY sent_at DESC, id DESC LIMIT 50`,
      { me: req.user.uid, other: Number(req.params.userId) });
    res.json(rows.reverse());
  } catch (e) { next(e); }
});
```

### 7.7 Módulo 9: estadísticas del panel administrativo

```js
// routes/admin.js (fragmento) — todo el router usa requireAuth + requireRole('administrador')
router.get('/stats', async (req, res, next) => {
  try {
    const [[s]] = await pool.query(`
      SELECT
        (SELECT COUNT(*) FROM users WHERE role_id = 1)                       AS totalUsers,
        (SELECT COUNT(DISTINCT uid) FROM (
            SELECT learner_id AS uid FROM exchanges WHERE created_at >= NOW() - INTERVAL 30 DAY
            UNION SELECT teacher_id FROM exchanges WHERE created_at >= NOW() - INTERVAL 30 DAY
            UNION SELECT sender_id  FROM messages  WHERE sent_at   >= NOW() - INTERVAL 30 DAY
         ) t)                                                                AS activeUsers,
        (SELECT COUNT(*) FROM reports WHERE status = 'pendiente')            AS pendingReports,
        (SELECT COUNT(*) FROM exchanges
          WHERE status = 'finalizado'
            AND updated_at >= DATE_FORMAT(NOW(), '%Y-%m-01'))                AS sessionsThisMonth`);
    res.json(s);
  } catch (e) { next(e); }
});
```

*(Define "usuario activo" en el informe: aquí = participó en un intercambio o envió un mensaje en los últimos 30 días.)*

---

## 8. Conectar el frontend con la API

### 8.1 Qué cambia

El `js/main.js` actual guarda puntos, suscripción, avatar y decoraciones en `localStorage`, y las listas de estudiantes están escritas en el HTML. Todo eso se sustituye por datos que vienen del servidor. La parte de interfaz (menús, popovers, pestañas, tema visual) **se queda igual**.

Orden recomendado de conversión (de lo que desbloquea más cosas a lo que menos):

1. `login.html`, `registro.html` → sesión real.
2. Encabezado y barra lateral del portal (nombre, puntos, rol) → `GET /auth/me`.
3. `perfil.html` → guardar perfil y habilidades.
4. `explorar.html` + matches.
5. `sesiones.html` + solicitudes.
6. `mensajes.html` → Socket.io.
7. `tienda.html`.
8. `admin.html`.

### 8.2 Ayudante para llamar a la API — `frontend/js/api.js`

Cárgalo con `<script src="js/api.js"></script>` **antes** de `main.js` en cada página que use datos.

```js
function readCookie(name) {
  const row = document.cookie.split('; ').find((r) => r.startsWith(name + '='));
  return row ? decodeURIComponent(row.split('=')[1]) : '';
}

async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch('/api' + path, {
    method,
    credentials: 'same-origin',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRF-Token': readCookie('csrf_token'),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && !/login\.html|registro\.html|index\.html/.test(location.pathname)) {
    location.href = 'login.html';          // sesión vencida o inexistente
  }
  if (!res.ok) throw Object.assign(new Error(data.error || 'Error de servidor'), { status: res.status, data });
  return data;
}
```

### 8.3 Ejemplo: `login.html`

1. Quita `data-redirect` del `<form>` (esa línea hace el "login falso" de `main.js`).
2. Agrega un lugar para el mensaje de error, justo antes del botón de enviar:
   ```html
   <p class="form-error" id="form-error" role="alert" hidden></p>
   ```
   ```css
   .form-error { color: #b3261e; font-size: 14px; margin: 0 0 12px; }
   ```
3. Crea `js/pages/login.js` y cárgalo con `defer`:

```js
const form = document.querySelector('form');
const errorBox = document.getElementById('form-error');

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  errorBox.hidden = true;
  const d = Object.fromEntries(new FormData(form));
  try {
    const user = await api('/auth/login', { method: 'POST', body: { email: d.email, password: d.password } });
    location.href = user.role === 'administrador' ? 'admin.html' : 'portal.html';
  } catch (err) {
    errorBox.textContent = err.message;      // textContent, nunca innerHTML
    errorBox.hidden = false;
  }
});
```

`registro.html` es igual, con `POST /auth/register` y el cuerpo `{ fullName: d.name, email: d.email, password: d.password, career: d.career, semester: d.semester }`.

### 8.4 Reglas de oro del frontend

- **Mostrar datos del servidor con `textContent`**, nunca con `innerHTML`. Un nombre de usuario como `<img src=x onerror=...>` ejecutaría código en el navegador de quien lo vea (XSS). `main.js` ya sigue esta regla; mantenla.
- **Ocultar** el enlace "Administración" a los estudiantes es solo estética. La protección real es `requireRole('administrador')` en el servidor.
- **Nunca** guardar contraseñas ni tokens en `localStorage`. La sesión vive en cookies HttpOnly.
- Mostrar un estado de **cargando** y un mensaje de **error** en cada pantalla que llame a la API.

