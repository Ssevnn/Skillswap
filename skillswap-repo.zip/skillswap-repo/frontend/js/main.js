/* ==========================================================
   SkillSwap - comportamiento (JavaScript sin dependencias)
   Un solo archivo para todas las páginas: cada bloque solo se
   activa si encuentra sus elementos en el HTML.
   ========================================================== */
(function () {
  'use strict';

  var $ = function (selector, root) { return (root || document).querySelector(selector); };
  var $$ = function (selector, root) { return Array.prototype.slice.call((root || document).querySelectorAll(selector)); };

  /* ---------- Menú móvil de la landing ---------- */
  var menuButton = $('.menu-button');
  var navLinks = $('#nav-links');
  if (menuButton && navLinks) {
    var setMenu = function (open) {
      navLinks.classList.toggle('is-open', open);
      menuButton.setAttribute('aria-expanded', String(open));
      menuButton.setAttribute('aria-label', open ? 'Cerrar menú' : 'Abrir menú');
    };
    menuButton.addEventListener('click', function () {
      setMenu(!navLinks.classList.contains('is-open'));
    });
    $$('a', navLinks).forEach(function (link) {
      link.addEventListener('click', function () { setMenu(false); });
    });
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') setMenu(false);
    });
  }

  /* ---------- Formulario "¿Qué habilidad quieres intercambiar?" ---------- */
  var joinForm = $('#join-form');
  var joinSuccess = $('#join-success');
  if (joinForm && joinSuccess) {
    joinForm.addEventListener('submit', function (event) {
      event.preventDefault();
      joinForm.hidden = true;
      joinSuccess.hidden = false;
    });
  }

  /* ---------- Login / registro ---------- */
  $$('[data-toggle-password]').forEach(function (button) {
    var input = document.getElementById(button.getAttribute('data-toggle-password'));
    if (!input) return;
    button.addEventListener('click', function () {
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      button.textContent = show ? 'Ocultar' : 'Ver';
      button.setAttribute('aria-pressed', String(show));
    });
  });

  $$('form[data-redirect]').forEach(function (form) {
    form.addEventListener('submit', function (event) {
      event.preventDefault(); // el navegador ya validó los campos "required"
      window.location.href = form.getAttribute('data-redirect');
    });
  });

  /* ---------- Portal: navegación lateral móvil ---------- */
  var sidebar = $('#portal-sidebar');
  var portalMenu = $('#portal-menu');
  var backdrop = $('#portal-backdrop');
  function setSidebar(open) {
    if (!sidebar || !portalMenu || !backdrop) return;
    sidebar.classList.toggle('open', open);
    backdrop.hidden = !open;
    portalMenu.setAttribute('aria-expanded', String(open));
    portalMenu.setAttribute('aria-label', open ? 'Cerrar navegación' : 'Abrir navegación');
  }
  if (sidebar && portalMenu && backdrop) {
    portalMenu.addEventListener('click', function () { setSidebar(!sidebar.classList.contains('open')); });
    backdrop.addEventListener('click', function () { setSidebar(false); });
    $$('a', sidebar).forEach(function (a) { a.addEventListener('click', function () { setSidebar(false); }); });
  }

  /* ---------- Portal: buscador ---------- */
  var students = [
    { name: 'Andrea Morales', initials: 'AM', career: 'Ing. de Software', teaches: 'Python y Git', learns: 'Inglés', match: 96, color: 'coral' },
    { name: 'Daniel López', initials: 'DL', career: 'Lic. en Redes', teaches: 'Ciberseguridad', learns: 'Figma', match: 91, color: 'blue' },
    { name: 'Sofía Castillo', initials: 'SC', career: 'Ing. Industrial', teaches: 'Excel avanzado', learns: 'SQL', match: 88, color: 'violet' },
    { name: 'Marco Herrera', initials: 'MH', career: 'Lic. en Inglés', teaches: 'Inglés B2', learns: 'Java', match: 85, color: 'green' },
    { name: 'Valeria Ríos', initials: 'VR', career: 'Diseño Gráfico', teaches: 'Figma y UX', learns: 'Python', match: 82, color: 'pink' },
    { name: 'Luis Acosta', initials: 'LA', career: 'Ing. Civil', teaches: 'Cálculo II', learns: 'Excel', match: 79, color: 'orange' }
  ];

  var searchInput = $('#search-input');
  var searchPopover = $('#search-popover');
  var searchResults = $('#search-results');
  var searchLabel = $('#search-label');
  var notifButton = $('#notif-button');
  var notifPopover = $('#notif-popover');

  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function pageLink(href) {
    var a = el('a');
    a.href = href;
    return a;
  }

  function renderSearch() {
    if (!searchResults) return;
    var query = searchInput.value.trim().toLowerCase();
    searchResults.textContent = '';
    searchLabel.textContent = query ? 'Resultados' : 'Explorar rápidamente';

    if (!query) {
      [['Explorar matches', 'Descubre perfiles compatibles', 'explorar.html'], ['Ver mi agenda', 'Revisa tus próximas sesiones', 'sesiones.html']]
        .forEach(function (item) {
          var a = pageLink(item[2]);
          var box = el('span');
          box.appendChild(el('strong', '', item[0]));
          box.appendChild(el('small', '', item[1]));
          a.appendChild(box);
          searchResults.appendChild(a);
        });
      return;
    }

    var found = students.filter(function (s) {
      return (s.name + ' ' + s.teaches + ' ' + s.learns + ' ' + s.career).toLowerCase().indexOf(query) !== -1;
    }).slice(0, 4);

    if (!found.length) {
      searchResults.appendChild(el('p', 'search-empty', 'No encontramos coincidencias. Prueba con otra habilidad.'));
      return;
    }
    found.forEach(function (s) {
      var a = pageLink('explorar.html');
      a.appendChild(el('span', 'search-avatar ' + s.color, s.initials));
      var box = el('span');
      box.appendChild(el('strong', '', s.name));
      box.appendChild(el('small', '', s.teaches + ' · ' + s.match + '% match'));
      a.appendChild(box);
      var arrow = el('span', '', '→');
      arrow.setAttribute('aria-hidden', 'true');
      a.appendChild(arrow);
      searchResults.appendChild(a);
    });
  }

  function setSearchOpen(open) {
    if (!searchPopover) return;
    searchPopover.hidden = !open;
    if (searchInput) searchInput.setAttribute('aria-expanded', String(open));
  }
  function setNotifOpen(open) {
    if (!notifPopover) return;
    notifPopover.hidden = !open;
    notifButton.setAttribute('aria-expanded', String(open));
  }

  if (searchInput && searchPopover) {
    renderSearch();
    searchInput.addEventListener('input', function () { renderSearch(); setSearchOpen(true); });
    searchInput.addEventListener('focus', function () { setSearchOpen(true); });
    $('#search-close').addEventListener('click', function () { setSearchOpen(false); });
    $('#portal-search').addEventListener('submit', function (event) {
      event.preventDefault();
      if (!searchInput.value.trim()) return;
      window.location.href = 'explorar.html';
    });
  }

  /* ---------- Portal: notificaciones ---------- */
  if (notifButton && notifPopover) {
    var count = $('#notif-count');
    notifButton.addEventListener('click', function () {
      setNotifOpen(notifPopover.hidden);
      setSearchOpen(false);
    });
    $('#notif-read').addEventListener('click', function () {
      count.hidden = true;
      notifButton.setAttribute('aria-label', 'Sin notificaciones nuevas');
    });
  }

  /* ---------- Portal: atajos y cierre de ventanas emergentes ---------- */
  if (searchInput || notifButton) {
    document.addEventListener('keydown', function (event) {
      var tag = event.target && event.target.tagName;
      if (event.key === '/' && searchInput && ['INPUT', 'TEXTAREA', 'SELECT'].indexOf(tag) === -1) {
        event.preventDefault();
        searchInput.focus();
        setSearchOpen(true);
      }
      if (event.key === 'Escape') {
        setSearchOpen(false);
        setNotifOpen(false);
        setSidebar(false);
      }
    });
    document.addEventListener('click', function (event) {
      if (searchPopover && !event.target.closest('.portal-search-wrap')) setSearchOpen(false);
      if (notifPopover && !event.target.closest('.notification-wrap')) setNotifOpen(false);
    });
  }

  /* ==========================================================
     Estado compartido entre páginas del portal (localStorage)
     Reemplaza el estado de React: puntos, suscripción, avatar,
     banner, decoraciones compradas y solicitudes enviadas.
     ========================================================== */
  var STORAGE_KEY = 'skillswap-state-v1';
  var defaults = {
    points: 1240, avatarUrl: '', bannerUrl: '', decoration: 'classic',
    ownedDecorations: ['classic'], subscription: 'Gratis', claimed: [], requested: []
  };
  var state = (function () {
    try {
      var saved = JSON.parse(window.localStorage.getItem(STORAGE_KEY));
      return Object.assign({}, defaults, saved || {});
    } catch (e) { return Object.assign({}, defaults); }
  })();
  function saveState() {
    try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (e) { /* sin espacio o bloqueado */ }
  }

  function paintAvatar(box) {
    if (!box) return;
    box.className = box.className.replace(/\bdecoration-\S+/g, '').replace(/\s+/g, ' ').trim() + ' decoration-' + state.decoration;
    var img = null, i;
    for (i = 0; i < box.children.length; i++) if (box.children[i].tagName === 'IMG') img = box.children[i];
    var text = box.firstChild;
    if (state.avatarUrl) {
      if (!img) { img = document.createElement('img'); img.alt = ''; box.insertBefore(img, box.firstChild); }
      img.src = state.avatarUrl;
      if (text && text.nodeType === 3) text.nodeValue = '';
    } else {
      if (img) box.removeChild(img);
      if (text && text.nodeType === 3) text.nodeValue = 'JG';
    }
  }

  function applyShared() {
    $$('[data-points]').forEach(function (n) { n.textContent = state.points.toLocaleString('en-US'); });
    $$('[data-points-label]').forEach(function (n) { n.textContent = state.points.toLocaleString('en-US') + ' SkillPoints'; });
    $$('[data-subscription]').forEach(function (n) { n.textContent = state.subscription; });
    $$('[data-subscription-line]').forEach(function (n) { n.textContent = state.subscription + ' · Ciberseguridad'; });
    $$('.mini-avatar, .profile-main-avatar').forEach(paintAvatar);
    var cover = $('.profile-cover');
    if (cover) {
      var banner = $('.profile-banner-image', cover);
      if (state.bannerUrl) {
        if (!banner) {
          banner = document.createElement('img');
          banner.className = 'profile-banner-image';
          banner.alt = 'Banner personalizado de Javier';
          cover.insertBefore(banner, cover.firstChild);
        }
        banner.src = state.bannerUrl;
      } else if (banner) { cover.removeChild(banner); }
    }
  }

  /* ---------- Explorar ---------- */
  var studentGrid = $('.student-grid');
  if (studentGrid) {
    var cards = $$('.student-card', studentGrid);
    var filterButtons = $$('.filter-tabs button');
    filterButtons.forEach(function (button) {
      button.addEventListener('click', function () {
        var category = button.getAttribute('data-filter');
        filterButtons.forEach(function (b) {
          var on = b === button;
          b.classList.toggle('active', on);
          b.setAttribute('aria-pressed', String(on));
        });
        cards.forEach(function (card) {
          var cats = card.getAttribute('data-category').split(' ');
          card.hidden = !(category === 'Todas' || cats.indexOf(category) !== -1);
        });
      });
    });
    var sortSelect = $('#sort-select');
    sortSelect.addEventListener('change', function () {
      var key = { match: 'data-match', rating: 'data-rating', recent: 'data-index' }[sortSelect.value];
      var sorted = cards.slice().sort(function (a, b) {
        var x = parseFloat(a.getAttribute(key)), y = parseFloat(b.getAttribute(key));
        return sortSelect.value === 'recent' ? x - y : y - x;
      });
      sorted.forEach(function (card) { studentGrid.appendChild(card); });
    });
    cards.forEach(function (card) {
      var button = $('[data-request]', card);
      var name = card.getAttribute('data-name');
      var paint = function () {
        var sent = state.requested.indexOf(name) !== -1;
        button.classList.toggle('request-sent', sent);
        button.textContent = sent ? 'Solicitud enviada' : 'Solicitar intercambio';
      };
      button.addEventListener('click', function () {
        if (state.requested.indexOf(name) === -1) { state.requested.push(name); saveState(); }
        paint();
      });
      paint();
    });
  }

  /* ---------- Mensajes ---------- */
  var messagesBox = $('#messages');
  if (messagesBox) {
    var contactButtons = $$('.contact-list button');
    contactButtons.forEach(function (button) {
      button.addEventListener('click', function () {
        contactButtons.forEach(function (b) { b.classList.toggle('active', b === button); });
        var avatar = $('#conv-avatar');
        avatar.className = 'student-avatar small ' + button.getAttribute('data-color');
        avatar.firstChild.nodeValue = button.getAttribute('data-initials');
        $('#conv-name').textContent = button.getAttribute('data-name');
        $('#conv-meta').textContent = 'En línea · ' + button.getAttribute('data-match') + '% de coincidencia';
      });
    });
    var messageForm = $('#message-form');
    var draft = $('#message-input');
    messageForm.addEventListener('submit', function (event) {
      event.preventDefault();
      var text = draft.value.trim();
      if (!text) return;
      var now = new Date();
      var hhmm = ('0' + now.getHours()).slice(-2) + ':' + ('0' + now.getMinutes()).slice(-2);
      var row = el('div', 'message me');
      row.appendChild(el('p', '', text));
      var time = el('time', '', 'Ahora');
      time.setAttribute('datetime', hhmm);
      row.appendChild(time);
      messagesBox.appendChild(row);
      draft.value = '';
      messagesBox.scrollTop = messagesBox.scrollHeight;
    });
    messagesBox.scrollTop = messagesBox.scrollHeight;
  }

  /* ---------- Sesiones: pestañas ---------- */
  var sectionTabs = $$('.section-tabs button');
  sectionTabs.forEach(function (button) {
    button.addEventListener('click', function () {
      sectionTabs.forEach(function (b) {
        b.classList.toggle('active', b === button);
        b.setAttribute('aria-pressed', String(b === button));
      });
    });
  });

  /* ---------- Tienda ---------- */
  var rewardGrid = $('.reward-grid');
  if (rewardGrid) {
    var yearly = false;
    var money = function (n) { return '$' + n.toFixed(2); };

    var refreshStore = function () {
      $$('.reward-card').forEach(function (card) {
        var title = card.getAttribute('data-title');
        var cost = Number(card.getAttribute('data-cost'));
        var button = $('button', card);
        var purchased = state.claimed.indexOf(title) !== -1;
        var unavailable = state.points < cost;
        button.disabled = purchased || unavailable;
        button.textContent = purchased ? 'Recompensa reclamada' : unavailable ? 'Puntos insuficientes' : 'Reclamar recompensa';
      });
      $$('.decoration-card').forEach(function (card) {
        var id = card.getAttribute('data-id');
        var cost = Number(card.getAttribute('data-cost'));
        var button = $('button', card);
        var active = state.decoration === id;
        var owned = state.ownedDecorations.indexOf(id) !== -1;
        button.disabled = active || (!owned && state.points < cost);
        button.textContent = active ? 'En uso' : owned ? 'Equipar' : state.points < cost ? 'Puntos insuficientes' : 'Comprar y equipar';
      });
      $$('.plan-card').forEach(function (card) {
        var name = card.getAttribute('data-name');
        var monthly = Number(card.getAttribute('data-monthly'));
        var price = yearly ? monthly * 0.8 : monthly;
        var button = $('button', card);
        var current = state.subscription === name;
        $('.plan-price strong', card).textContent = money(price);
        var billing = $('.plan-billing', card);
        billing.hidden = !(yearly && monthly > 0);
        billing.textContent = 'Facturado ' + money(price * 12) + ' al año';
        button.disabled = current;
        button.textContent = current ? 'Plan actual' : monthly === 0 ? 'Cambiar a Gratis' : 'Elegir ' + name;
      });
      applyShared();
    };

    rewardGrid.addEventListener('click', function (event) {
      var button = event.target.closest('button');
      if (!button) return;
      var card = button.closest('.reward-card');
      var title = card.getAttribute('data-title');
      var cost = Number(card.getAttribute('data-cost'));
      if (state.points < cost || state.claimed.indexOf(title) !== -1) return;
      state.points -= cost;
      state.claimed.push(title);
      saveState(); refreshStore();
    });
    $$('.decoration-card button').forEach(function (button) {
      button.addEventListener('click', function () {
        var card = button.closest('.decoration-card');
        var id = card.getAttribute('data-id');
        var cost = Number(card.getAttribute('data-cost'));
        if (state.ownedDecorations.indexOf(id) === -1) {
          if (state.points < cost) return;
          state.points -= cost;
          state.ownedDecorations.push(id);
        }
        state.decoration = id;
        saveState(); refreshStore();
      });
    });
    $$('.plan-card button').forEach(function (button) {
      button.addEventListener('click', function () {
        state.subscription = button.closest('.plan-card').getAttribute('data-name');
        saveState(); refreshStore();
      });
    });
    $$('.billing-toggle button').forEach(function (button) {
      button.addEventListener('click', function () {
        yearly = button.getAttribute('data-billing') === 'yearly';
        $$('.billing-toggle button').forEach(function (b) {
          b.classList.toggle('active', b === button);
          b.setAttribute('aria-pressed', String(b === button));
        });
        refreshStore();
      });
    });
    refreshStore();
  }

  /* ---------- Perfil ---------- */
  var profileForm = $('#profile-form');
  if (profileForm) {
    var editing = false;
    var editButton = $('#edit-profile');
    var savedNote = $('#profile-saved');
    var setEditing = function (on) {
      editing = on;
      $$('[data-editable]', profileForm).forEach(function (field) { field.disabled = !on; });
      $$('[data-add-tag]').forEach(function (b) { b.hidden = !on; });
      $('#profile-save').hidden = !on;
      editButton.textContent = on ? 'Cancelar' : 'Editar perfil';
    };
    editButton.addEventListener('click', function () { setEditing(!editing); });
    $('#edit-availability').addEventListener('click', function () { setEditing(true); });
    profileForm.addEventListener('submit', function (event) {
      event.preventDefault();
      setEditing(false);
      savedNote.hidden = false;
    });

    // Reduce la imagen antes de guardarla para no llenar el localStorage
    var shrink = function (file, maxSize, done) {
      var reader = new FileReader();
      reader.onload = function () {
        var img = new Image();
        img.onload = function () {
          var scale = Math.min(1, maxSize / Math.max(img.width, img.height));
          var canvas = document.createElement('canvas');
          canvas.width = Math.round(img.width * scale);
          canvas.height = Math.round(img.height * scale);
          canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
          done(canvas.toDataURL('image/jpeg', 0.85));
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    };
    $('#banner-file').addEventListener('change', function (event) {
      var file = event.target.files && event.target.files[0];
      if (file) shrink(file, 1400, function (url) { state.bannerUrl = url; saveState(); applyShared(); });
    });
    $('#avatar-file').addEventListener('change', function (event) {
      var file = event.target.files && event.target.files[0];
      if (file) shrink(file, 300, function (url) { state.avatarUrl = url; saveState(); applyShared(); });
    });

    var selector = $('#decoration-selector');
    var names = { classic: 'Clásico', aura: 'Aura eléctrica', neon: 'Neón coral', laurels: 'Laureles de mentor', cosmos: 'Órbita cósmica' };
    var renderSelector = function () {
      selector.textContent = '';
      state.ownedDecorations.forEach(function (id) {
        var button = el('button', state.decoration === id ? 'active' : '');
        button.type = 'button';
        button.setAttribute('aria-pressed', String(state.decoration === id));
        button.appendChild(el('span', 'decoration-dot decoration-' + id, 'JG'));
        button.appendChild(el('small', '', names[id] || id));
        button.addEventListener('click', function () {
          state.decoration = id; saveState(); applyShared(); renderSelector();
        });
        selector.appendChild(button);
      });
    };
    renderSelector();
    setEditing(false);
  }

  /* ---------- Administración: reportes ---------- */
  $$('.report-list article button').forEach(function (button) {
    button.addEventListener('click', function () {
      button.closest('article').classList.add('resolved');
      button.textContent = 'Resuelto';
    });
  });

  applyShared();
})();
