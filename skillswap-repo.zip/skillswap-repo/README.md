# SkillSwap — Red de Intercambio de Habilidades Académicas

Proyecto de Programación Web, Universidad Tecnológica de Panamá.

## Estructura
- `frontend/` — sitio HTML5 + CSS + JavaScript (11 páginas). Abre `frontend/index.html`.
- `backend/` — API Node.js + Express + MySQL (en construcción). Scripts SQL en `backend/sql/`.
- `docs/` — guía de implementación paso a paso.

## Cómo ejecutar el frontend
Abre `frontend/index.html` con la extensión Live Server de VS Code.

## Cómo preparar la base de datos
1. Crea la base y el usuario (ver `docs/GUIA_SkillSwap_Backend_MySQL.md`, sección 5.1).
2. Ejecuta `mysql -u root -p < backend/sql/schema.sql` y luego `seed.sql`.
3. Copia `backend/.env.example` a `backend/.env` y completa los valores.

## Flujo de trabajo del equipo
- `main` siempre estable; trabajar en ramas `feature/nombre-corto`.
- Todo cambio entra por Pull Request con al menos una revisión.
- Nunca subir `.env` ni contraseñas.
