USE skillswap;

INSERT INTO roles (id, name) VALUES (1, 'estudiante'), (2, 'administrador');

INSERT INTO categories (name) VALUES ('Tecnología'), ('Idiomas'), ('Diseño'), ('Ciencias');

INSERT INTO skills (category_id, name) VALUES
  (1, 'Python'), (1, 'Java'), (1, 'Git'), (1, 'SQL'), (1, 'Ciberseguridad'), (1, 'Redes'), (1, 'Excel'),
  (2, 'Inglés'), (2, 'Francés'), (2, 'Portugués'),
  (3, 'Figma'), (3, 'UX/UI'),
  (4, 'Cálculo'), (4, 'Física'), (4, 'Estadística');

INSERT INTO rewards (type, code, title, description, cost) VALUES
  ('beneficio','perfil_destacado','Perfil destacado','Aparece primero en los resultados durante 7 días.',450),
  ('beneficio','insignia_mentor','Insignia Mentor','Muestra tu experiencia y compromiso en el perfil.',700),
  ('beneficio','cambio_match','Cambio de match','Desbloquea tres recomendaciones adicionales.',250),
  ('beneficio','tema_nocturno','Tema nocturno','Personaliza tu experiencia con un tema exclusivo.',350),
  ('beneficio','taller_premium','Taller premium','Accede a un taller grupal impartido por un mentor.',900),
  ('beneficio','racha_protegida','Racha protegida','Conserva tu racha si omites una semana.',200),
  ('decoracion','aura','Aura eléctrica','Un aro azul brillante para destacar tu avatar.',320),
  ('decoracion','neon','Neón coral','Borde luminoso con los colores de SkillSwap.',450),
  ('decoracion','laurels','Laureles de mentor','Reconoce visualmente tu experiencia enseñando.',600),
  ('decoracion','cosmos','Órbita cósmica','Una órbita animada exclusiva para tu perfil.',750);
