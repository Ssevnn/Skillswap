USE skillswap;

-- ---------- Usuarios y roles ----------
CREATE TABLE roles (
  id   TINYINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(20) NOT NULL UNIQUE            -- 'estudiante' | 'administrador'
);

CREATE TABLE users (
  id            INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  role_id       TINYINT UNSIGNED NOT NULL DEFAULT 1,
  full_name     VARCHAR(120) NOT NULL,
  email         VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,        -- hash bcrypt, NUNCA la contraseña
  career        VARCHAR(100),
  semester      VARCHAR(30),
  bio           TEXT,
  avatar_url    VARCHAR(255),
  banner_url    VARCHAR(255),
  decoration    VARCHAR(30) NOT NULL DEFAULT 'classic',
  status        ENUM('activo','en_revision','bloqueado') NOT NULL DEFAULT 'activo',
  skill_points  INT NOT NULL DEFAULT 0,       -- saldo; se mueve solo vía points_ledger
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_users_role FOREIGN KEY (role_id) REFERENCES roles(id),
  CONSTRAINT chk_points_nonneg CHECK (skill_points >= 0)
);

CREATE TABLE password_resets (
  id         INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  user_id    INT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL,               -- SHA-256 del token enviado por correo
  expires_at DATETIME NOT NULL,
  used_at    DATETIME NULL,
  CONSTRAINT fk_reset_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_reset_token (token_hash)
);

-- ---------- Habilidades ----------
CREATE TABLE categories (
  id   SMALLINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(60) NOT NULL UNIQUE
);

CREATE TABLE skills (
  id          INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  category_id SMALLINT UNSIGNED NOT NULL,
  name        VARCHAR(80) NOT NULL UNIQUE,
  CONSTRAINT fk_skills_cat FOREIGN KEY (category_id) REFERENCES categories(id)
);

CREATE TABLE user_skills (
  user_id  INT UNSIGNED NOT NULL,
  skill_id INT UNSIGNED NOT NULL,
  kind     ENUM('ofrece','busca') NOT NULL,
  PRIMARY KEY (user_id, skill_id, kind),
  CONSTRAINT fk_us_user  FOREIGN KEY (user_id)  REFERENCES users(id)  ON DELETE CASCADE,
  CONSTRAINT fk_us_skill FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE CASCADE,
  INDEX idx_us_skill (skill_id, kind)
);

CREATE TABLE availability (
  id         INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  user_id    INT UNSIGNED NOT NULL,
  weekday    TINYINT UNSIGNED NOT NULL,       -- 1 = lunes ... 7 = domingo
  start_time TIME NOT NULL,
  end_time   TIME NOT NULL,
  CONSTRAINT fk_av_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT chk_av_day  CHECK (weekday BETWEEN 1 AND 7),
  CONSTRAINT chk_av_time CHECK (end_time > start_time)
);

-- ---------- Intercambios ----------
CREATE TABLE exchanges (
  id               INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  learner_id       INT UNSIGNED NOT NULL,     -- quien solicita y aprende
  teacher_id       INT UNSIGNED NOT NULL,     -- quien enseña
  skill_id         INT UNSIGNED NOT NULL,     -- habilidad que se enseña
  offered_skill_id INT UNSIGNED NULL,         -- lo que el aprendiz ofrece a cambio (trueque)
  status           ENUM('pendiente','aceptado','rechazado','finalizado') NOT NULL DEFAULT 'pendiente',
  scheduled_at     DATETIME NULL,             -- se guarda en UTC
  duration_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 60,
  modality         ENUM('virtual','presencial') NULL,
  meeting_url      VARCHAR(255) NULL,         -- enlace de Meet / Teams (limitación de la propuesta)
  location         VARCHAR(150) NULL,
  created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_ex_learner FOREIGN KEY (learner_id) REFERENCES users(id),
  CONSTRAINT fk_ex_teacher FOREIGN KEY (teacher_id) REFERENCES users(id),
  CONSTRAINT fk_ex_skill   FOREIGN KEY (skill_id)   REFERENCES skills(id),
  CONSTRAINT fk_ex_offered FOREIGN KEY (offered_skill_id) REFERENCES skills(id),
  CONSTRAINT chk_ex_diff   CHECK (learner_id <> teacher_id),
  INDEX idx_ex_teacher (teacher_id, status),
  INDEX idx_ex_learner (learner_id, status)
);

-- ---------- Chat ----------
CREATE TABLE messages (
  id          BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  sender_id   INT UNSIGNED NOT NULL,
  receiver_id INT UNSIGNED NOT NULL,
  body        VARCHAR(1000) NOT NULL,
  sent_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  read_at     TIMESTAMP NULL,
  CONSTRAINT fk_msg_sender   FOREIGN KEY (sender_id)   REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_msg_receiver FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_msg_pair (sender_id, receiver_id, sent_at),
  INDEX idx_msg_inbox (receiver_id, read_at)
);

-- ---------- Calificaciones ----------
CREATE TABLE reviews (
  id             INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  exchange_id    INT UNSIGNED NOT NULL,
  reviewer_id    INT UNSIGNED NOT NULL,
  reviewed_id    INT UNSIGNED NOT NULL,
  punctuality    TINYINT UNSIGNED NOT NULL,
  knowledge      TINYINT UNSIGNED NOT NULL,
  responsibility TINYINT UNSIGNED NOT NULL,
  comment        VARCHAR(500) NULL,
  created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_review_once (exchange_id, reviewer_id),
  CONSTRAINT fk_rev_ex       FOREIGN KEY (exchange_id) REFERENCES exchanges(id) ON DELETE CASCADE,
  CONSTRAINT fk_rev_reviewer FOREIGN KEY (reviewer_id) REFERENCES users(id),
  CONSTRAINT fk_rev_reviewed FOREIGN KEY (reviewed_id) REFERENCES users(id),
  CONSTRAINT chk_rev_p CHECK (punctuality    BETWEEN 1 AND 5),
  CONSTRAINT chk_rev_k CHECK (knowledge      BETWEEN 1 AND 5),
  CONSTRAINT chk_rev_r CHECK (responsibility BETWEEN 1 AND 5)
);

-- ---------- SkillPoints y tienda ----------
CREATE TABLE rewards (
  id          INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  type        ENUM('beneficio','decoracion') NOT NULL,
  code        VARCHAR(30) NOT NULL UNIQUE,    -- p. ej. 'aura', 'perfil_destacado'
  title       VARCHAR(80) NOT NULL,
  description VARCHAR(200) NOT NULL,
  cost        INT UNSIGNED NOT NULL,
  active      BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE user_rewards (
  user_id    INT UNSIGNED NOT NULL,
  reward_id  INT UNSIGNED NOT NULL,
  claimed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, reward_id),
  CONSTRAINT fk_ur_user   FOREIGN KEY (user_id)   REFERENCES users(id)   ON DELETE CASCADE,
  CONSTRAINT fk_ur_reward FOREIGN KEY (reward_id) REFERENCES rewards(id)
);

CREATE TABLE points_ledger (
  id          BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  user_id     INT UNSIGNED NOT NULL,
  amount      INT NOT NULL,                   -- positivo = gana, negativo = gasta
  reason      ENUM('hora_ensenada','sesion_completada','bono_resena','canje') NOT NULL,
  exchange_id INT UNSIGNED NULL,
  reward_id   INT UNSIGNED NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pl_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_pl_user (user_id, created_at)
);

-- ---------- Moderación ----------
CREATE TABLE reports (
  id          INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  reporter_id INT UNSIGNED NOT NULL,
  reported_id INT UNSIGNED NOT NULL,
  reason      VARCHAR(120) NOT NULL,
  details     TEXT NULL,
  status      ENUM('pendiente','resuelto') NOT NULL DEFAULT 'pendiente',
  resolved_by INT UNSIGNED NULL,
  resolved_at DATETIME NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_rep_reporter FOREIGN KEY (reporter_id) REFERENCES users(id),
  CONSTRAINT fk_rep_reported FOREIGN KEY (reported_id) REFERENCES users(id),
  INDEX idx_rep_status (status, created_at)
);

CREATE TABLE blocks (
  blocker_id INT UNSIGNED NOT NULL,
  blocked_id INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (blocker_id, blocked_id),
  CONSTRAINT fk_bl_blocker FOREIGN KEY (blocker_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_bl_blocked FOREIGN KEY (blocked_id) REFERENCES users(id) ON DELETE CASCADE
);
